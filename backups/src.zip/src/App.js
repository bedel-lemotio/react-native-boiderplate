/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import 'react-native-gesture-handler';
import React from 'react';
import { StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import HomeScreen from "./ui/features/home/HomeScreen";
import LoginScreen from "./ui/features/login/LoginScreen";
import RegisterScreen from "./ui/features/register/RegisterScreen";
import WelcomeScreen from "./ui/features/welcome/WelcomeScreen";


const Stack = createStackNavigator();


export default class App extends React.Component {

  render() {
    return (
        <NavigationContainer>
          <Stack.Navigator screenOptions={{headerShown:false}} initialRouteName="Welcome">
              <Stack.Screen
                  name="Welcome"
                  component={WelcomeScreen}
              />
              <Stack.Screen
                  name="Login"
                  component={LoginScreen}
              />
              <Stack.Screen
                  name="Register"
                  component={RegisterScreen}
              />
              <Stack.Screen
                  name="Home"
                  component={HomeScreen}
              />

          </Stack.Navigator>
        </NavigationContainer>

    );
  }
}





