/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React from 'react';
import {
  StyleSheet,
  View,
  Text,
  Button
} from 'react-native';



export default class RegisterScreen extends React.Component {
  render() {
    return (
        <View style={styles.container}>
          <Text>You have (undefined) friends.</Text>

          <Button
              title="Navigate to home"
              onPress={() =>
                  this.props.navigation.navigate('Home')
              }
          />
        </View>
    );
  }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#003f5c',
        alignItems: 'center',
        justifyContent: 'center',
    },

});





