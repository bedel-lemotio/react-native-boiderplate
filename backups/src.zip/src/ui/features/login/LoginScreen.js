/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React from 'react';
import {
  StyleSheet,
  View,
  Text,
  Button
} from 'react-native';



export default class LoginScreen extends React.Component {
  render() {
    return (
        <View style={styles.container}>
          <Text>Bedel test.</Text>

          <Button
              title="Navigate to home"
              onPress={() => {

                  console.log("test");
                  alert("test");
                  this.props.navigation.navigate('Register');
              }
              }
          />

        </View>
    );
  }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#FFF',
        alignItems: 'center',
        justifyContent: 'center',
    },

});





