/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React from 'react';
import {
    StyleSheet,
    View,
    Text,
    Button,
    TextInput
} from 'react-native';
import {Icon} from "react-native-elements";



export default class WelcomeScreen extends React.Component {
  render() {
    return (
        <View style={styles.container}>
            <View style={styles.statutbar} >
                <Icon
                    raised
                    name='heartbeat'
                    type='font-awesome'
                    color='#f50'
                    onPress={() => console.log('hello')} />
            </View>
            <View style={styles.headercontainer} >
                <Text>So what gives ?</Text>
            </View>
            <View style={styles.bodycontainer} >

            </View>
            <View style={styles.footercontainer} >

                <Button
                    title="Navigate to home"
                    onPress={() => {
                        //console.log("test");
                        //alert("test");
                        this.props.navigation.navigate('Login');
                       }
                    }
                />

            </View>



        </View>
    );
  }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#FFF',
        alignItems: 'center',
        justifyContent: 'center',
    },
    statutbar: {
        flex: 2,
        alignItems: 'flex-end',
        justifyContent: 'center',
    },
    headercontainer: {
        flex: 2,
        backgroundColor: '#FFF',
        alignItems: 'center',
        justifyContent: 'center',
    },
    bodycontainer: {
        flex: 2,
        backgroundColor: '#FFF',
        alignItems: 'center',
        justifyContent: 'center',
    },
    footercontainer: {
        flex: 1,
        backgroundColor: '#FFF',
        alignItems: 'center',
        justifyContent: 'center',
    },

});





