/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React from 'react';
import {
    StyleSheet,
    View,
    Text,
    Button,
    TextInput
} from 'react-native';
import {Icon} from "react-native-elements";



export default class WelcomeScreen extends React.Component {
  render() {
    return (
        <View style={styles.container}>
            <View style={styles.statutbar} >
                <Icon type="MaterialCommunityIcons" name="barcode" color='#0074D9' onPress={() => {console.log("test");}} />
            </View>
            <View style={styles.headercontainer} >

                <View style={styles.container_icon_header}>
                    <Icon reverse name="barcode" color='#0074D9' containerStyle={styles.icon_header} />
                </View>

                <Text numberOfLines={1}
                      adjustsFontSizeToFit
                      style={{textAlign:'center',fontSize:30 ,fontWeight:"bold"}}> So what gives </Text>

            </View>
            <View style={styles.bodycontainer} >
                <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }}>
                    <Icon reverse name="barcode" color='#0074D9' containerStyle={styles.icon_header} />
                    <View style={{ flexDirection: 'column', justifyContent: 'center', alignItems: 'flex-start' }}>
                        <Text>Answer a few simple questions</Text>
                        <Text>about your business</Text>
                    </View>
                </View>
                <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }}>
                    <Icon reverse name="barcode" color='#0074D9' containerStyle={styles.icon_header} />
                    <View style={{ flexDirection: 'column', justifyContent: 'center', alignItems: 'flex-start' }}>
                        <Text>Answer a few simple questions</Text>
                        <Text>about your business</Text>
                    </View>
                </View>
                <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }}>
                    <Icon reverse name="barcode" color='#0074D9' containerStyle={styles.icon_header} />
                    <View style={{ flexDirection: 'column', justifyContent: 'center', alignItems: 'flex-start' }}>
                        <Text>Answer a few simple questions</Text>
                        <Text>about your business</Text>
                    </View>
                </View>
            </View>
            <View style={styles.footercontainer} >
                <Button
                    title="Navigate to home"
                    onPress={() => {
                        console.log("test");
                        alert("test");
                        this.props.navigation.navigate('Register');
                    }
                    }
                />
            </View>



        </View>
    );
  }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 30,
        backgroundColor: 'white',

    },
    statutbar: {
        flex: 1,
        alignItems: 'flex-end',
        width: "auto",
        justifyContent: 'center',
    },
    headercontainer: {
        flex: 2,
        justifyContent: 'center',
        alignItems: 'center',
    },
    container_icon_header: {

    },
    icon_header: {

    },
    bodycontainer: {
        flex: 3,

        alignItems: 'center',
        width: "100%",
        justifyContent: 'center',
    },
    footercontainer: {
        flex: 2,

        alignItems: 'center',
        justifyContent: 'center',
    },

});





